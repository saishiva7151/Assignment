import hashlib
import time
import mmh3
import cityhash
import farmhash

def hash_md5(input_string):
    return hashlib.md5(input_string.encode()).hexdigest()

def hash_sha1(input_string):
    return hashlib.sha1(input_string.encode()).hexdigest()

def hash_sha256(input_string):
    return hashlib.sha256(input_string.encode()).hexdigest()

def hash_sha512(input_string):
    return hashlib.sha512(input_string.encode()).hexdigest()

def hash_blake2s(input_string):
    return hashlib.blake2s(input_string.encode()).hexdigest()

# Implement MurmurHash3, CityHash, FarmHash, and Whirlpool based on your environment and requirements


def hash_murmur3(input_string):
    return mmh3.hash(input_string)  # You might need to adjust the return value as needed


def hash_city(input_string):
    return cityhash.CityHash64(input_string)  # You might need to adjust the return value as needed

def hash_farm(input_string):
    # You may need to install a FarmHash library or implement the hash function
    # FarmHash is not a built-in hash function in hashlib
    pass



def hash_whirlpool(input_string):
    # You may need to install a Whirlpool library or implement the hash function
    # Whirlpool is not a built-in hash function in hashlib
    pass


# Define the hash functions to be tested
hash_functions = [
    ("MD5", hash_md5),
    ("SHA-1", hash_sha1),
    ("SHA-256", hash_sha256),
    ("SHA-512", hash_sha512),
    ("BLAKE2s", hash_blake2s),
    # Add more hash functions as needed
    ("MurmurHash3", hash_murmur3),
    ("City Hash", hash_city),
    ("Farm Hash", hash_farm),
    ("Whirlpool", hash_whirlpool),
       
]

def calculate_hash_time(input_string, hash_func, num_iterations=10):
    total_time = 0.0
    for _ in range(num_iterations):
        start_time = time.time()
        hash_func(input_string)
        end_time = time.time()
        total_time += (end_time - start_time)
    average_time = total_time / num_iterations
    return average_time

def main():
    input_string = "hello world, how are you hope you are doning great and fantastic"
    
    print("Results:")
    print("{:<10} {:<20} {:<15} {:<15} {:<15} {:<15} {:<15}".format(
        "Serial No.", "Hash Function", "Language Used", "Input Size (bits)", 
        "Output Size (bits)", "Time (seconds)", "Priority"
    ))
    
    # Record the time for each hash function
    for i, (hash_name, hash_func) in enumerate(hash_functions, start=1):
        # Dummy values for input and output sizes (bits) for demonstration purposes
        input_size_bits = len(input_string) * 8
        output_size_bits = 128 if "MD5" in hash_name else 160 if "SHA-1" in hash_name else 256
        
        average_time = calculate_hash_time(input_string, hash_func)
        
        # Assign priority values based on execution times
        # Smaller time means higher priority (1 is the highest priority)
        priority = i
        print("{:<10} {:<20} {:<15} {:<15} {:<15} {:<15.6f} {:<15}".format(
            i, hash_name, "Python", input_size_bits, output_size_bits, average_time, priority
        ))

if __name__ == "__main__":
    main()
