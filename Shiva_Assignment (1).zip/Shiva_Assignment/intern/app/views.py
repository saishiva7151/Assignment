# Create your views here.

from django.contrib.auth import authenticate, login, logout
from django.shortcuts import render, redirect
from .forms import UserLoginForm
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
# from .forms import FileUploadForm
from .forms import UserLoginForm, UserRegistrationForm, FileUploadForm
from .models import UploadedFile

from django.contrib import messages  # Import messages module


def home(request):
    return render(request, 'home.html')

def about(request):
    return render(request, 'about.html')

def user_registration(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            # login(request, user)
            messages.success(request, 'Registration successful. Please log in.')  # Add success message
            return redirect('user_login')  # Replace 'index' with your home page URL name
    else:
        form = UserRegistrationForm()
    return render(request, 'registration.html', {'form': form})


def user_login(request):
    if request.method == 'POST':
        form = UserLoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user:
                login(request, user)
                return redirect('index')  # Redirect to your dashboard view
    else:
        form = UserLoginForm()
    return render(request, 'login.html', {'form': form})

def user_logout(request):
    logout(request)
    return redirect('login')  # Redirect to your login view

@login_required
def index(request):
    if request.method == 'POST':
        form = FileUploadForm(request.POST, request.FILES)
        if form.is_valid():
            file_obj = form.save(commit=False)
            file_obj.user = request.user
            file_obj.save()
            return redirect('file_list')  # Redirect to file list page after upload
    else:
        form = FileUploadForm()

    uploaded_files = UploadedFile.objects.filter(user=request.user)
    return render(request, 'index.html', {'form': form, 'uploaded_files': uploaded_files})



@login_required
def upload_file(request):
    if request.method == 'POST':
        form = FileUploadForm(request.POST, request.FILES)
        if form.is_valid():
            file_obj = form.save(commit=False)
            file_obj.user = request.user
            file_obj.save()
            return redirect('file_list')
    else:
        form = FileUploadForm()
    return render(request, 'upload_file.html', {'form': form})

@login_required
def file_list(request):
    uploaded_files = UploadedFile.objects.filter(user=request.user)
    return render(request, 'file_list.html', {'uploaded_files': uploaded_files})

def user_logout(request):
    logout(request)
    return redirect('user_login')  # Replace 'user_login' with your login page URL name