# authentication/urls.py

from django.urls import path
from .views import user_login, user_logout, upload_file, user_registration,  index, file_list, home, about


urlpatterns = [
    path('', home, name='home'),
    path('about/', about, name='about'),
    path('register/', user_registration, name='user_registration'),
    path('login/', user_login, name='user_login'),
    path('index', index, name='index'),
    path('logout/', user_logout, name='user_logout'),
    path('upload/', upload_file, name='upload_file'),
    path('file_list/', file_list, name='file_list'),
    # Add more URLs for registration, profile, etc.
]
